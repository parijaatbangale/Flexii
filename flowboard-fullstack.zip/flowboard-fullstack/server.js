const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/flowboard';

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const taskSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true, maxlength: 100 },
  category: { type: String, enum: ['Study', 'Personal', 'Project', 'Health'], default: 'Personal' },
  priority: { type: String, enum: ['High', 'Medium', 'Low'], default: 'Medium' },
  done: { type: Boolean, default: false },
  dueDate: { type: Date, default: null }
}, { timestamps: true });
const Task = mongoose.model('Task', taskSchema);

app.get('/api/health', (_req, res) => res.json({ status: 'ok', database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected' }));
app.get('/api/tasks', async (_req, res, next) => {
  try { res.json(await Task.find().sort({ createdAt: -1 })); } catch (err) { next(err); }
});
app.post('/api/tasks', async (req, res, next) => {
  try {
    const { title, category, priority, dueDate } = req.body;
    if (!title || !title.trim()) return res.status(400).json({ error: 'Task title is required.' });
    const task = await Task.create({ title: title.trim(), category, priority, dueDate: dueDate || null });
    res.status(201).json(task);
  } catch (err) { next(err); }
});
app.patch('/api/tasks/:id', async (req, res, next) => {
  try {
    const allowed = ['title', 'category', 'priority', 'done', 'dueDate'];
    const update = Object.fromEntries(Object.entries(req.body).filter(([key]) => allowed.includes(key)));
    const task = await Task.findByIdAndUpdate(req.params.id, update, { new: true, runValidators: true });
    if (!task) return res.status(404).json({ error: 'Task not found.' });
    res.json(task);
  } catch (err) { next(err); }
});
app.delete('/api/tasks/:id', async (req, res, next) => {
  try {
    const task = await Task.findByIdAndDelete(req.params.id);
    if (!task) return res.status(404).json({ error: 'Task not found.' });
    res.status(204).end();
  } catch (err) { next(err); }
});
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(err.name === 'ValidationError' ? 400 : 500).json({ error: err.name === 'ValidationError' ? err.message : 'Internal server error.' });
});

mongoose.connect(MONGODB_URI)
  .then(() => app.listen(PORT, () => console.log(`Flowboard running at http://localhost:${PORT}`)))
  .catch(err => { console.error('Could not connect to MongoDB:', err.message); process.exit(1); });
