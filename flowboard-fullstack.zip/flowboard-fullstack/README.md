# Flowboard — full-stack starter

An interactive task dashboard built with:
- Frontend: HTML, CSS, vanilla JavaScript
- Backend: Node.js + Express REST API
- Database: MongoDB via Mongoose

## Run locally

1. Install Node.js 18+ and install/start MongoDB locally, or create a MongoDB Atlas database.
2. Open a terminal in this folder and run `npm install`.
3. Copy `.env.example` to `.env` and set `MONGODB_URI` to your MongoDB connection string. (The example local URI is the default.)
4. Start the server with `npm start`.
5. Visit `http://localhost:3000`.

The API routes are `GET /api/health`, `GET /api/tasks`, `POST /api/tasks`, `PATCH /api/tasks/:id`, and `DELETE /api/tasks/:id`.

## Important note about this starter

`public/index.html` is a self-contained interactive prototype and uses browser `localStorage` so its demo works in a static preview. To make the browser UI persist through the included MongoDB API, replace the demo `localStorage` reads/writes and local task mutations with `fetch('/api/tasks')` calls. The Express/Mongoose API is implemented and ready for that wiring; no real database connection is available inside the ChatGPT preview.
